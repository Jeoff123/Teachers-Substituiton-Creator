#!/bin/bash

# Define paths
DESKTOP_FILE="/usr/share/applications/launch.desktop"
FILES_DIR="/usr/share/Substitution Creator"
LOGO_FILE="/usr/share/Substitution Creator/logo.png"

# Remove application files
if [ -f "$DESKTOP_FILE" ]; then
    sudo rm "$DESKTOP_FILE"
    echo "Removed desktop file."
else
    echo "Desktop file not found."
fi

if [ -f "$LOGO_FILE" ]; then
    sudo rm "$LOGO_FILE"
    echo "Removed logo file."
else
    echo "Logo file not found."
fi

if [ -d "$FILES_DIR" ]; then
    sudo rm -r "$FILES_DIR"
    echo "Removed application files directory."
else
    echo "Application files directory not found."
fi

# Optional: Remove Python packages (uncomment if needed)
# python3.8 -m pip uninstall -y pyqt5 reportlab

# Update desktop database
sudo update-desktop-database

# Notify user of uninstallation status
notify-send "Uninstallation Complete" "The application has been uninstalled successfully."

