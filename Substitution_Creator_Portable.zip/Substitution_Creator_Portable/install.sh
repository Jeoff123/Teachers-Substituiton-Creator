#!/bin/bash

# Update package lists
sudo apt-get update

# Install Python 3.8 and pip
sudo apt install -y python3.8 python3-pip
python3.8 -m pip install --upgrade pip
sudo apt-get update
sudo apt-get install build-essential libgl1-mesa-dev
python3.8 -m pip cache purge
python3.8 -m pip install pyqt5 --only-binary :all:

# Install Python packages
python3.8 -m pip install pyqt5 reportlab

# Create necessary directories
sudo mkdir -p "/usr/share/Substitution Creator"

# Copy files
sudo cp launch.desktop /usr/share/applications/
sudo cp logo.png "/usr/share/Substitution Creator/"
sudo cp -r files "/usr/share/Substitution Creator/"

# Set executable permissions
sudo chmod +x "/usr/share/Substitution Creator/files/main.py"
sudo chmod +x "/usr/share/applications/launch.desktop"

# Update desktop database
sudo update-desktop-database

# Define paths
DESKTOP_FILE="/usr/share/applications/launch.desktop"
FILES_DIR="/usr/share/Substitution Creator/files/"

# Check if the desktop file exists and directory contains required files
if [ -f "$DESKTOP_FILE" ] && [ -d "$FILES_DIR" ]; then
    if [ -f "$FILES_DIR/main.py" ] && [ -f "$FILES_DIR/algorithm.py" ] && [ -f "$FILES_DIR/schedule_manager.py" ] && [ -f "$FILES_DIR/teacher_manager.py" ]; then
        notify-send "Successfully installed" "The application has been installed with all necessary files."
    else
        notify-send "Not installed" "Some required files are missing."
    fi
else
    notify-send "Not installed" "The application or directory is missing."
fi

